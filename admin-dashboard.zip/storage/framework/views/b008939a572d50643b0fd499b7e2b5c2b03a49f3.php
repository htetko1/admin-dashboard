<div class="row">
    <div class="col-12 col-lg-6">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb bg-transparent">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <?php echo e($slot); ?>

            </ol>
        </nav>
    </div>
</div>
<?php /**PATH D:\source\Laravel\admin-dashboard\resources\views/components/bread-crumb.blade.php ENDPATH**/ ?>