<?php $__env->startSection("title"); ?> <?php echo e($article->title); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection("head"); ?>
    <style>
        .description{
            white-space: pre-line;
        }
    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.bread-crumb','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bread-crumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <li class="breadcrumb-item"><a href="<?php echo e(route('article.index')); ?>">Article List</a></li>
        <li class="breadcrumb-item active" aria-current="page">Article Detail</li>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <div class="row">
        <div class="col-12 col-lg-6">
            <div class="card">
                <div class="card-body">
                    <h4 class="mb-0">
                        <?php echo e($article->title); ?>

                    </h4>
                    <div class="mt-1 text-primary">
                        <span class="small mx-2 font-weight-bold">
                            <i class="feather-layers"></i>
                            <?php echo e($article->category->title); ?>

                        </span>
                        <span class="small mx-2 font-weight-bold">
                            <i class="feather-user"></i>
                            <?php echo e($article->user->name); ?>

                        </span>
                        <span class="small mx-2 font-weight-bold">
                                        <i class="feather-calendar"></i>
                                        <?php echo e($article->created_at->format('d-m-y')); ?>

                                    </span>
                        <span class="small mx-2 font-weight-bold">
                                         <i class="feather-clock"></i>
                                        <?php echo e($article->created_at->format('h:i A')); ?>

                                    </span>
                    </div>
                    <p class="text-black-50 description">
                        <?php echo e($article->description); ?>

                    </p>
                    <hr>
                    <div class="d-flex justify-content-between align-items-center">
                        <div class="">
                            <a href="<?php echo e(route('article.edit',$article->id)); ?>" class="btn btn-outline-primary">
                                Edit
                            </a>
                            <form action="<?php echo e(route('article.destroy',[$article->id,"page"=>request()->page])); ?>" class="d-inline-block" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button class="btn btn-outline-danger" onclick="return confirm('Are you sure to delete this article?')">Delete</button>
                            </form>
                            <a href="<?php echo e(route('article.index')); ?>" class="btn btn-outline-dark">
                                All Article
                            </a>
                        </div>
                        <p><?php echo e($article->created_at->diffForHumans()); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\source\Laravel\admin-dashboard\resources\views/article/show.blade.php ENDPATH**/ ?>