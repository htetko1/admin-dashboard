
<?php $__env->startSection('content'); ?>
    <div class="">
        <div class="py-3">

            <div class="small post-category mb-3">
                <a href="<?php echo e(route('baseOnCategory',$article->category->id)); ?>" rel="category tag"><?php echo e($article->category->title); ?></a>
            </div>

            <h2 class="fw-bolder"><?php echo e($article->title); ?></h2>
            <div class="my-3 feature-image-box">
                <div class="d-block d-md-flex justify-content-between align-items-center my-3">

                    <div class="">
                        <?php if($article->user->name): ?>
                            <img alt="" src="<?php echo e(asset('storage/profile/'.$article->user->photo)); ?>"
                                 class="avatar avatar-50 photo rounded-circle" height="50" width="50"
                                 loading="lazy">
                        <?php else: ?>
                            <img alt="" src="<?php echo e(asset('dashboard/img/hetko.jpg')); ?>"
                                 class="avatar avatar-50 photo rounded-circle" height="50" width="50"
                                 loading="lazy">
                        <?php endif; ?>
                            <a href="<?php echo e(route('baseOnUser',$article->user->id)); ?>"  class="ms-2 text-decoration-none"><?php echo e($article->user->name); ?></a>
                    </div>

                    <div class="text-primary">
                        <i class="feather-calendar"></i>
                        <a href="<?php echo e(route('baseOnDate',$article->created_at)); ?>" class="text-decoration-none">
                            <?php echo e($article->created_at->format("d F Y H:i a")); ?>

                        </a>
                    </div>
                </div>

                <p class="text-black-50" style="white-space: pre-line">
                    <?php echo e($article->description); ?>

                </p>
                <?php
                    $previous = \App\Models\Article::where("id","<","$article->id")->latest("id")->first();
                    $next = \App\Models\Article::where("id",">","$article->id")->first();
                ?>

                <div class="nav d-flex justify-content-between p-3">
                    <a href="<?php echo e(isset($previous)? route('detail',$previous->slug):'#'); ?>"
                       class="btn btn-outline-primary page-mover rounded-circle <?php if(empty($previous)): ?> disabled <?php endif; ?>">
                        <i class="feather-chevron-left"></i>
                    </a>

                    <a class="btn btn-outline-primary px-3 rounded-pill" href="<?php echo e(route('index')); ?>">
                        Read All
                    </a>

                    <a href="<?php echo e(isset($next)? route('detail',$next->slug):'#'); ?>"
                       class="btn btn-outline-primary page-mover rounded-circle <?php if(empty($next)): ?> disabled <?php endif; ?>">
                        <i class="feather-chevron-right"></i>
                    </a>
                </div>
            </div>


        </div>

        <div class="d-block d-lg-none d-flex justify-content-center">
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('blog.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\source\Laravel\admin-dashboard\resources\views/blog/detail.blade.php ENDPATH**/ ?>