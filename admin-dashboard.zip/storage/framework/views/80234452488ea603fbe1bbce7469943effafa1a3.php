<?php $__env->startSection("title"); ?> User-manager <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.bread-crumb','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bread-crumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">User-Manager</li>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4>
                        <i class="feather-users"></i>
                        User List
                    </h4>
                    <table class="table table-hover">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Control</th>
                            <th>Created At</th>
                            <th>Updated At</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($user->id); ?></td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><?php echo e($user->role ? "User" : "Admin"); ?></td>
                            <td>
                                <?php if($user->role == 1): ?>
                                    <form class="d-inline-block" action="<?php echo e(route('user-manager.makeAdmin')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                                        <button class="btn btn-sm btn-outline-primary">Make Admin</button>
                                    </form>

                                <button class="btn btn-sm btn-outline-warning" onclick="changePassword(<?php echo e($user->id); ?>,'<?php echo e($user->name); ?>')">Change Password</button>

                                   <?php if($user->isBaned == 1): ?>
                                       <span>Baned</span>
                                    <?php else: ?>
                                        <form class="d-inline-block" action="<?php echo e(route('user-manager.ban-user')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                                            <button class="btn btn-sm btn-outline-danger">Ban User</button>
                                        </form>
                                   <?php endif; ?>
                                    <?php if($user->isBaned == 1): ?>
                                        <form class="d-inline-block" action="<?php echo e(route('user-manager.restore-user')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                                            <button class="btn btn-sm btn-outline-success">Restore User</button>
                                        </form>
                                    <?php endif; ?>
                                <?php endif; ?>

                            </td>
                            <td>
                                <small>
                                    <i class="feather-calendar"></i>
                                    <?php echo e($user->created_at->format("d F y")); ?>

                                    <br>
                                    <i class="feather-clock"></i>
                                    <?php echo e($user->created_at->format("h:i a")); ?>

                                </small>
                            </td>
                            <td>
                                <small>
                                    <i class="feather-calendar"></i>
                                    <?php echo e($user->updated_at->format("d F y")); ?>

                                    <br>
                                    <i class="feather-clock"></i>
                                    <?php echo e($user->updated_at->format("h:i a")); ?>

                                </small>
                            </td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script>
        function changePassword(id,name){
            let url = "<?php echo e(route('user-manager.change-user-password')); ?>"
            Swal.fire({
                title: 'Change Password for '+name,
                input: 'password',
                inputAttributes: {
                    autocapitalize: 'off',
                    required : 'required',
                    minLength:8,
                },
                showCancelButton: true,
                confirmButtonText: 'Change',
                showLoaderOnConfirm: true,
                preConfirm : function (newPassword){
                    // console.log(id,newPassword);
                    $.post(url,{
                        id:id,
                        password:newPassword,
                        _token:"<?php echo e(csrf_token()); ?>"
                    }).done(function (data){
                        if (data.status == 200){
                            Swal.fire({
                                icon:"success",
                                title:data.message
                            })
                        }else {
                            Swal.fire({
                                icon:"error",
                                title:data.message.password[0]
                            })
                        }
                    })
                }

            })
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\source\Laravel\admin-dashboard\resources\views/user-manager/index.blade.php ENDPATH**/ ?>