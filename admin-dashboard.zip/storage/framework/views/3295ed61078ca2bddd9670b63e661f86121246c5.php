<table class="table table-bordered table-hover">
    <thead>
    <tr>
        <th>#</th>
        <th>Title</th>
        <th>Owner</th>
        <th>Controls</th>
        <th>Created_at</th>
    </tr>
    </thead>
    <tbody>
    <?php $__empty_1 = true; $__currentLoopData = \App\Models\Category::with("user")->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($category->id); ?></td>
            <td><?php echo e($category->title); ?></td>
            <td><?php echo e($category->user->name); ?></td>
            <td >
                <a href="<?php echo e(route('category.edit',$category->id)); ?>" class="btn btn-outline-primary">
                    Edit
                </a>
                <form action="<?php echo e(route('category.destroy',$category->id)); ?>" class="d-inline-block" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button class="btn btn-outline-danger" onclick="return confirm('Are you sure to delete <?php echo e($category->title); ?> category?')">Delete</button>
                </form>
            </td>
            <td>
             <span class="small">
              <i class="feather-calendar"></i>
              <?php echo e($category->created_at->format('d-m-y')); ?>

              </span>
                <br>
                <span class="small">
                <i class="feather-clock"></i>
                <?php echo e($category->created_at->format('h:i A')); ?>

                </span>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="5" class="text-center">There is no Category</td>
        </tr>
    <?php endif; ?>
    </tbody>
</table>
<?php /**PATH D:\source\Laravel\admin-dashboard\resources\views/category/list.blade.php ENDPATH**/ ?>