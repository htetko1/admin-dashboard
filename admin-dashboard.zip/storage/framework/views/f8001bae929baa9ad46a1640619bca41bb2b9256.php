<li class="menu-spacer"></li>
<?php /**PATH D:\source\Laravel\admin-dashboard\resources\views/components/menu-spacer.blade.php ENDPATH**/ ?>