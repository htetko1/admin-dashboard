<?php if(session('toast')): ?>

    <script>

        let toastInfo = <?php echo json_encode(session('toast'), 15, 512) ?>;

        // console.log(toastInfo);

        const Toast = Swal.mixin({
            toast: true,
            position: 'top-right',
            iconColor: 'white',
            customClass: {
                popup: 'colored-toast'
            },
            showConfirmButton: false,
            timer: 1500,
            timerProgressBar: true
        })
        await Toast.fire({
            icon: 'success',
            title: 'success'
        })
        // await Toast.fire({
        //     icon: 'error',
        //     title: 'Error'
        // })
        // await Toast.fire({
        //     icon: 'warning',
        //     title: 'Warning'
        // })
        // await Toast.fire({
        //     icon: 'info',
        //     title: 'Info'
        // })
        // await Toast.fire({
        //     icon: 'question',
        //     title: 'Question'


</script>
<?php endif; ?>

<?php /**PATH D:\source\Laravel\admin-dashboard\resources\views/toast.blade.php ENDPATH**/ ?>