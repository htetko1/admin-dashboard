<li class="menu-title"><?php echo e($title); ?></li>
<?php /**PATH D:\source\Laravel\admin-dashboard\resources\views/components/menu-title.blade.php ENDPATH**/ ?>