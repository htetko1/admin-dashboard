<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title><?php echo $__env->yieldContent('title','Admin Dashboard'); ?></title>
    <!-- CSS only -->
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>" />
    <link rel="icon" href="<?php echo e(asset('images/images/cropped-logo.png')); ?>">
    <?php echo $__env->yieldContent('head'); ?>
</head>

<body>
<?php if(auth()->guard()->guest()): ?>
    <?php echo $__env->yieldContent('content'); ?>
<?php else: ?>
    <section class="main container-fluid">
        <div class="row">
            <!-- sidebar start -->
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- sidebar end -->

            <div class="col-12 col-lg-9 col-xl-10 py-3 vh-100 content">
            <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- content area start -->
            <?php echo $__env->yieldContent("content"); ?>
            <!-- content area end -->
            </div>
        </div>
    </section>
<?php endif; ?>



<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/js/dashboard.js')); ?>"></script>
<?php echo $__env->yieldContent('foot'); ?>

<?php if(auth()->guard()->check()): ?>
    <?php echo $__env->make("user-profile.update-info", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>


</body>

</html>
<?php /**PATH D:\source\Laravel\admin-dashboard\resources\views/layouts/app.blade.php ENDPATH**/ ?>