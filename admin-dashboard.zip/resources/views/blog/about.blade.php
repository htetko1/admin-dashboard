@extends('blog.master')
@section('title') About @endsection

@section('content')
    <h1>I'm about</h1>

@endsection
