<div class="row">
    <div class="col-12 col-lg-6">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb bg-transparent">
                <li class="breadcrumb-item"><a href="{{ route('home') }}">Home</a></li>
                {{ $slot }}
            </ol>
        </nav>
    </div>
</div>
