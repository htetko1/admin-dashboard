<?php


namespace App;


class Base
{
    public static $name = "IT News";
    public static $logo = "images/images/cropped-logo.png";
    public static $description = "ကျောင်းသားတွေကို လေ့ကျင့်တဲ့ project ဖြစ်ပါတယ်။";
}
